package com.rodrigo.cryptosignalpro;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String CHANNEL = "signals";
    private static final int NOTIF_REQ = 42;
    private WebView web;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,11,16));
        createChannel();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(9,11,16));
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(this), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Señales CryptoSignal Pro",NotificationManager.IMPORTANCE_HIGH));
        }
    }
    public static class Bridge {
        private final Context c;
        Bridge(Context c){this.c=c;}
        @JavascriptInterface public void notifySignal(String symbol,String signal,String score,String price){
            if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
            String title="CryptoSignal Pro · "+signal;
            String body=symbol+" · score "+score+" · $"+price+" · marco 1H";
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
            b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify((symbol+signal).hashCode(),b.build());
        }
    }
    @Override public void onBackPressed(){
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
