# CryptoSignal Pro 3.0

App Android de análisis de criptomonedas 1H. **No ejecuta órdenes y no solicita API keys.**

## Funciones
- 200 velas 1H para el panel y hasta 1000 velas para backtest.
- Velas japonesas reales de Binance Futures, soportes/resistencias por pivotes.
- RSI, MACD, EMA 20/50/200, ADX, Stoch RSI, Bollinger, ATR, OBV, MFI e Ichimoku.
- Volumen relativo, Funding Rate, Open Interest, cambio de OI 1H y ratio global Long/Short cuando están disponibles.
- Motor de confluencia LONG/SHORT/NEUTRAL con score 1–99 y plan de entrada/SL/TP basado en ATR y estructura.
- Scanner multi-mercado para 16 pares.
- Backtester de hasta 1000 velas: entrada al cierre de señal, horizonte 24H, TP 1.5R y SL 1R. Si una misma vela toca SL y TP, cuenta SL primero.
- Alertas Android para cambios a LONG/SHORT fuertes (score >=75 o <=25). En esta versión la aplicación debe permanecer abierta para evaluar señales.

## Datos
Usa endpoints públicos de Binance. Klines 1H y derivados se consultan en tiempo real. Binance documenta límites y disponibilidad de los endpoints; Open Interest histórico está limitado a una ventana reciente. Ver documentación oficial: https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api.

## Compilar
Abrir en Android Studio y ejecutar `assembleDebug`. También incluye GitHub Actions en `.github/workflows/build.yml` para generar el APK automáticamente en un runner.

## Instalación
El APK debug resultante se encuentra en `app/build/outputs/apk/debug/app-debug.apk`. En el Redmi Note 15 Pro+ se puede instalar activando la instalación de apps desde el origen utilizado.

## Aviso
El backtest es una simulación. No incluye comisiones, slippage, latencia ni financiación. Los resultados históricos no garantizan resultados futuros. Las señales no son asesoramiento financiero.
